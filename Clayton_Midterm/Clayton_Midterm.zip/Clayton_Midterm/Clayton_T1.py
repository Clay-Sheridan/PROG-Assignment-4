'''Clayton Nelson 991664284'''
#Task 1

class Departures:
   def __init__(self, departTime, status, destination, airlineName, flightNo, terminalNo, gateNo):
      self.departTime = departTime
      self.status = status
      self.destination = destination
      self.airlineName = airlineName
      self.flightNo = flightNo
      self.terminalNo = terminalNo
      self.gateNo = gateNo

   def __str__(self):
      self

firstFlight = Departures()
secondFlight = Departures()
   
   
   
   


   


